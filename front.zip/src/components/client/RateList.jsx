import React from 'react';

const RateList = () => {
    return (
        <div>
            
        </div>
    );
}

export default RateList;
