import React from 'react';

const ClientHome = () => {
    return (
        <div>
            
        </div>
    );
}

export default ClientHome;
