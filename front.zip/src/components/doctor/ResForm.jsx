import React from 'react';

const ResForm = () => {
    return (
        <div>
            
        </div>
    );
}

export default ResForm;
