import React from 'react';

const DoctorHome = () => {
    return (
        <div>
            
        </div>
    );
}

export default DoctorHome;
