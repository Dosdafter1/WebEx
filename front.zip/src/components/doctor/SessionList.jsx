import React from 'react';

const SessionList = () => {
    return (
        <div>
            
        </div>
    );
}

export default SessionList;
