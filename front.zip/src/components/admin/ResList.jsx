import React from 'react';

const ResList = () => {
    return (
        <div>
            
        </div>
    );
}

export default ResList;
