import React from 'react';

const CardList = () => {
    return (
        <div>
            
        </div>
    );
}

export default CardList;
