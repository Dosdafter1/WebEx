import React from 'react';

const AdminHome = () => {
    return (
        <div>
            
        </div>
    );
}

export default AdminHome;
